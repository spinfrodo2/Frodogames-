# RconServer
Control your PocketMine-MP server remotely using RCON tools

## Installing
- Drop the plugin in your `plugins` folder and restart the server.
- It will generate a `rcon.yml` file with default settings. If you want to customize the settings, stop the server, edit `rcon.yml`, and start the server again.
